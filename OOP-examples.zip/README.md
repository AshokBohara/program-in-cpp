# C-Arrayy
C++ using array
